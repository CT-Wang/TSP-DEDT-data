function dY=odefunfull_g(t,Y,C,S,fac)

    dY=zeros(6,1);
    dY(1)=Y(4);
    dY(2)=Y(5);
    dY(3)=Y(6);
    [U,f]=full_model2(Y(1),Y(2),Y(3),C,S,fac);
    dY(4:6)=f;

end