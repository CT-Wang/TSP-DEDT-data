%�������
clear;
clc;
% format long;

C=importdata('C.mat');
S=importdata('S.mat');
fac=importdata('fac.mat');
u=398600.4415e9; %������������m^3/s^2
J2=1.08263e-3;%����
Re=6378137;%����

% R1E0=[3499966.64851189;
%       26630.9089540003;
%       6062356.0562936;
%       -8.092538664639703;
%       7541.317060883819;
%       13.793760951379799];%m,m/s
LEO0=[-388.9e3;
    7738.8e3;
    673.6e3;
    -3.5794e3;
    0;
    6.1997e3];%m,m/s  LEO
HEO0=[4.05e6;
    0;
    -7.0148e6;
    0;
    9.1464e3;
    0];%m,m/s
GEO0=[4.2164e7;
    0;
    0;
    0;
    3.0747e3;
    0];%m,m/s

LEO_S_tspan=[0,8000];
HEO_S_tspan=[0,50000];
GEO_S_tspan=[0,90000];
LEO_L_tspan=[0,80000];
HEO_L_tspan=[0,500000];
GEO_L_tspan=[0,900000];
options = odeset('RelTol',1e-10,'AbsTol',1e-10);

%%��ϼ�����������������
% tic
% ode45_LEO_S=ode45(@odefunfull_g,LEO_S_tspan,LEO0,options,C,S,fac);
% toc%17.147432
% tic
% ode45_HEO_S=ode45(@odefunfull_g,HEO_S_tspan,HEO0,options,C,S,fac);
% toc%30.040141 
% tic
% ode45_GEO_S=ode45(@odefunfull_g,GEO_S_tspan,GEO0,options,C,S,fac);
% toc%17.141442
% save('ode45_LEO_S.mat','ode45_LEO_S');
% save('ode45_HEO_S.mat','ode45_HEO_S');
% save('ode45_GEO_S.mat','ode45_GEO_S');
% 
tic
ode45_LEO_L=ode45(@odefunfull_g,LEO_L_tspan,LEO0,options,C,S,fac);
toc%73.40 
tic
ode45_HEO_L=ode45(@odefunfull_g,HEO_L_tspan,HEO0,options,C,S,fac);
toc% 104.35
tic
ode45_GEO_L=ode45(@odefunfull_g,GEO_L_tspan,GEO0,options,C,S,fac);
toc%68.42
save('ode45_LEO.mat','ode45_LEO_L');
save('ode45_HEO.mat','ode45_HEO_L');
save('ode45_GEO.mat','ode45_GEO_L');

