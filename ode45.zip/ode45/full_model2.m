% This function generates the gravity force f of the full model, as well as
% the corresponding Jacobian matrix J.
function [U,f]=full_model2(x,y,z,C,S,fac)
u=3986004.415e8;R=6378136.3;%parameters
r=sqrt(x.^2+y.^2+z.^2);miu=z./r;lambda=2*pi*(y<0)+(-1).^(y<0).*acos(x./sqrt(x.^2+y.^2));
P=zeros(length(x),2,2);
P(:,1,1)=ones(size(x));P(:,2,1)=miu;P(:,2,2)=sqrt(1-miu.^2);
dP=zeros(length(x),1,1);d2P=zeros(length(x),1,1);
dUdr=0;dUdmiu=0;dUdlambda=0;U=0;
d2Udr2=0;d2Udmiu2=0;d2Udlambda2=0;
for n=2:40 %n: degree of EGM2008
    for m=0:n %m: order of EGM2008(a square model is used)
        n_=n+1;m_=m+1;
        if m==0
            P(:,n_,m_)=((2*n-1)*miu.*P(:,n_-1,1)-(n-1)*P(:,n_-2,1))/n;
        end
        if m==n
            P(:,n_,m_)=(2*n-1)*sqrt(1-miu.^2).*P(:,n_-1,n_-1);
        end
        if m==(n-1)
            P(:,n_,m_)=(2*n-1)*miu.*P(:,n_-1,n_-1);
        end
        if m~=0&&m~=n&&m~=(n-1)
            P(:,n_,m_)=(2*n-1)/(n-m)*miu.*P(:,n_-1,m_)-(n+m-1)/...
            (n-m)*P(:,n_-2,m_);
        end
%         P(:,n_,m_)=(m==0)*((2*n-1)*miu.*P(:,n_-1,1)-(n-1)*P(:,n_-2,1))+...
%             (m==n)*((2*n-1)*sqrt(1-miu.^2).*P(:,n_-1,n_-1))+...
%             (m==(n-1))*((2*n-1)*miu.*P(:,n_-1,n_-1))+...
%             (m~=0&&m~=n&&m~=(n-1))*((2*n-1)/(n-m)*miu.*P(:,n_-1,m_)-(n+m-1)/...
%             (n-m)*P(:,n_-2,m_));
        if n>2
            dP(:,n_-1,m_)=((m-n)*P(:,n_,m_)+n*miu.*P(:,n_-1,m_))./(1-miu.^2);
        end
        if n>3
            d2P(:,n_-2,m_)=((-1+n+2*miu.^2+3*(n-2)*miu.^2+(n-2)^2*miu.^2).*...
                P(:,n_-2,m_)+(1+m-n)*((5+2*(n-2))*miu.*P(:,n_-1,m_)+(m-n)*P(:,n_,m_)))...
                ./(miu.^2-1).^2;
            
            if m<=n-2
                nor=sqrt(((m==0)*1+(m~=0)*2)*(2*n-3)*fac(n-m-2+1)/fac(n+m-2+1));
                
                U_=(R./r).^(n-2)*nor.*P(:,n_-2,m_).*(C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)+S((n_+2)/2*(n_-3)+m_)*...
                    sin(m*lambda));
                
                U=U+U_;

                dUdr_=(R./r).^(n-2)*(n-1)*nor.*P(:,n_-2,m_).*(C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)+S((n_+2)/2*(n_-3)+m_)*...
                    sin(m*lambda));
                dUdmiu_=(R./r).^(n-2)*nor.*dP(:,n_-2,m_).*(C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)+...
                    S((n_+2)/2*(n_-3)+m_)*sin(m*lambda));
                dUdlambda_=(R./r).^(n-2)*nor.*P(:,n_-2,m_).*(-C((n_+2)/2*(n_-3)+m_)*sin(m*lambda)*m+S((n_+2)/2*(n_-3)+m_)*...
                    cos(m*lambda)*m);

                dUdr=dUdr+dUdr_;dUdmiu=dUdmiu+dUdmiu_;dUdlambda=dUdlambda+dUdlambda_;

%                 d2Udr2_=(R./r).^(n-2)*(n-1)*n*nor.*P(:,n_-2,m_).*(C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)+...
%                     S((n_+2)/2*(n_-3)+m_)*sin(m*lambda));
%                 d2Udmiu2_=(R./r).^(n-2)*nor.*d2P(:,n_-2,m_).*(C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)+...
%                     S((n_+2)/2*(n_-3)+m_)*sin(m*lambda));
%                 d2Udlambda2_=(R./r).^(n-2)*nor.*P(:,n_-2,m_).*(-C((n_+2)/2*(n_-3)+m_)*cos(m*lambda)*m^2-...
%                     S((n_+2)/2*(n_-3)+m_)*sin(m*lambda)*m^2);
% 
%                 d2Udr2=d2Udr2+d2Udr2_;d2Udmiu2=d2Udmiu2+d2Udmiu2_;
%                 d2Udlambda2=d2Udlambda2+d2Udlambda2_;
            end
        end
    end
end

U=(u./r).*(1+U);

dUdr=-(u./r.^2).*(dUdr+1);dUdmiu=(u./r).*(dUdmiu);dUdlambda=(u./r).*(dUdlambda);
f=[dUdr.*(x./r);dUdr.*(y./r);dUdr.*(z./r)]+[dUdmiu.*(-x.*z./r.^3);...
    dUdmiu.*(-y.*z./r.^3);dUdmiu.*((x.^2+y.^2)./r.^3)]+...
    [dUdlambda.*(-y./(x.^2+y.^2));dUdlambda.*(x./(x.^2+y.^2));zeros(size(x))];

% d2Udr2=(u./r.^3).*(2+d2Udr2);d2Udmiu2=(u./r).*d2Udmiu2;
% d2Udlambda2=(u./r).*d2Udlambda2;
end